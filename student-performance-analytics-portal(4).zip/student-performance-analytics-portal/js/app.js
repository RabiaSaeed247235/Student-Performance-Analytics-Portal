(() => {
  "use strict";

  const STORAGE_KEYS = {
    users: "edutrackUsers",
    currentUser: "edutrackCurrentUser",
    resetEmail: "edutrackResetEmail",
    students: "edutrackStudents",
    theme: "edutrackTheme",
    notifications: "edutrackNotifications"
  };

  const DEFAULT_USERS = [
    { name: "Ayesha Khan", email: "student@edutrack.com", password: "Student123", role: "student" },
    { name: "Ms. Sana Ahmed", email: "teacher@edutrack.com", password: "Teacher123", role: "teacher" },
    { name: "Portal Administrator", email: "admin@edutrack.com", password: "Admin123", role: "administrator" }
  ];

  const DEFAULT_STUDENTS = [
    { id: "ST-1001", name: "Ayesha Khan", attendance: 94, overall: 91, grade: "A+", assignment: 93, quiz: 90, mid: 88, final: 94 },
    { id: "ST-1002", name: "Hamza Ali", attendance: 88, overall: 84, grade: "B+", assignment: 82, quiz: 86, mid: 79, final: 87 },
    { id: "ST-1003", name: "Sara Ahmed", attendance: 92, overall: 87, grade: "A", assignment: 89, quiz: 84, mid: 86, final: 90 },
    { id: "ST-1004", name: "Bilal Raza", attendance: 79, overall: 73, grade: "C+", assignment: 71, quiz: 74, mid: 69, final: 78 },
    { id: "ST-1005", name: "Mahnoor Fatima", attendance: 96, overall: 89, grade: "A", assignment: 91, quiz: 87, mid: 85, final: 92 },
    { id: "ST-1006", name: "Usman Tariq", attendance: 86, overall: 78, grade: "B", assignment: 78, quiz: 76, mid: 74, final: 83 }
  ];

  function readStorage(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function writeStorage(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      return false;
    }
  }

  function removeStorage(key) {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      // Local storage is a simulation. The UI remains usable if storage is unavailable.
    }
  }

  function normalizeRole(role) {
    return ["administrator", "teacher", "student"].includes(role) ? role : "student";
  }

  function ensureInitialData() {
    const storedUsers = readStorage(STORAGE_KEYS.users, []);
    const users = Array.isArray(storedUsers) ? storedUsers.map((user) => ({ ...user, role: normalizeRole(user.role) })) : [];

    DEFAULT_USERS.forEach((demoUser) => {
      if (!users.some((user) => String(user.email).toLowerCase() === demoUser.email.toLowerCase())) {
        users.push({ ...demoUser });
      }
    });
    writeStorage(STORAGE_KEYS.users, users);

    const students = readStorage(STORAGE_KEYS.students, null);
    if (!Array.isArray(students) || students.length === 0) {
      writeStorage(STORAGE_KEYS.students, DEFAULT_STUDENTS);
    }

    const notifications = readStorage(STORAGE_KEYS.notifications, null);
    if (!Array.isArray(notifications)) {
      writeStorage(STORAGE_KEYS.notifications, [
        { id: 1, title: "Performance reports updated", message: "Latest student performance records are ready to review.", read: false },
        { id: 2, title: "Attendance reminder", message: "Please verify this week's attendance entries.", read: false },
        { id: 3, title: "Portal notice", message: "Your dashboard interface now supports role-based navigation.", read: false }
      ]);
    }
  }

  ensureInitialData();

  function getCurrentUser() {
    const user = readStorage(STORAGE_KEYS.currentUser, null);
    return user && typeof user === "object" ? { ...user, role: normalizeRole(user.role) } : null;
  }

  function roleDashboardPath(role) {
    const paths = {
      administrator: "admin-dashboard.html",
      teacher: "teacher-dashboard.html",
      student: "student-dashboard.html"
    };
    return paths[normalizeRole(role)];
  }

  function debounce(callback, delay = 180) {
    let timeoutId;
    return (...args) => {
      window.clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => callback(...args), delay);
    };
  }

  function applyTheme(theme) {
    const selectedTheme = theme === "dark" ? "dark" : "light";
    document.documentElement.dataset.theme = selectedTheme;
    const button = document.querySelector(".theme-toggle");
    if (button) {
      button.setAttribute("aria-pressed", String(selectedTheme === "dark"));
      button.textContent = selectedTheme === "dark" ? "☀ Light" : "◐ Dark";
      button.setAttribute("aria-label", selectedTheme === "dark" ? "Switch to light mode" : "Switch to dark mode");
    }
  }

  applyTheme(readStorage(STORAGE_KEYS.theme, "light"));

  const navbar = document.querySelector(".navbar");
  if (navbar && !navbar.querySelector(".theme-toggle")) {
    const themeButton = document.createElement("button");
    themeButton.type = "button";
    themeButton.className = "theme-toggle";
    const menuToggle = navbar.querySelector(".menu-toggle");
    navbar.insertBefore(themeButton, menuToggle || navbar.querySelector(".nav-links"));
    applyTheme(readStorage(STORAGE_KEYS.theme, "light"));
    themeButton.addEventListener("click", () => {
      const nextTheme = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
      writeStorage(STORAGE_KEYS.theme, nextTheme);
      applyTheme(nextTheme);
    });
  }

  const currentUser = getCurrentUser();
  if (currentUser) {
    document.querySelectorAll('a[href="dashboard.html"]').forEach((link) => {
      link.href = roleDashboardPath(currentUser.role);
    });
    document.querySelectorAll('a[href="login.html"]').forEach((link) => {
      if (!link.closest(".auth-links") && !link.closest(".auth-prompt")) {
        link.href = "account-profile.html";
        link.textContent = "Profile";
      }
    });
  }

  const requiredRole = document.body.dataset.requiredRole;
  if (requiredRole) {
    if (!currentUser) {
      window.location.replace("login.html");
    } else if (normalizeRole(currentUser.role) !== requiredRole) {
      window.location.replace(roleDashboardPath(currentUser.role));
    }
  }

  if (document.body.dataset.roleRouter === "true" && currentUser) {
    window.location.replace(roleDashboardPath(currentUser.role));
  }

  document.querySelectorAll("[data-current-user-name]").forEach((element) => {
    element.textContent = currentUser ? currentUser.name : "Guest";
  });
  document.querySelectorAll("[data-current-user-role]").forEach((element) => {
    element.textContent = currentUser ? normalizeRole(currentUser.role) : "guest";
  });

  const menuButton = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (menuButton && navLinks) {
    menuButton.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(isOpen));
    });

    navLinks.addEventListener("click", (event) => {
      if (event.target.closest("a")) {
        navLinks.classList.remove("open");
        menuButton.setAttribute("aria-expanded", "false");
      }
    });

    document.addEventListener("click", (event) => {
      if (!navLinks.contains(event.target) && !menuButton.contains(event.target)) {
        navLinks.classList.remove("open");
        menuButton.setAttribute("aria-expanded", "false");
      }
    });

    window.addEventListener("resize", () => {
      if (window.innerWidth > 760) {
        navLinks.classList.remove("open");
        menuButton.setAttribute("aria-expanded", "false");
      }
    });
  }

  function setMessage(element, text, type = "") {
    if (!element) return;
    element.textContent = text;
    element.classList.remove("success", "error");
    if (type) element.classList.add(type);
  }

  function isValidEmail(email) {
    return /^\S+@\S+\.\S+$/.test(email);
  }

  function gradeClass(grade) {
    if (String(grade).startsWith("A")) return "grade-a";
    if (String(grade).startsWith("B")) return "grade-b";
    return "grade-c";
  }

  function getStudents() {
    const students = readStorage(STORAGE_KEYS.students, DEFAULT_STUDENTS);
    return Array.isArray(students) ? students : DEFAULT_STUDENTS;
  }

  function saveStudents(students) {
    writeStorage(STORAGE_KEYS.students, students);
  }

  function getUsers() {
    const users = readStorage(STORAGE_KEYS.users, DEFAULT_USERS);
    return Array.isArray(users) ? users : DEFAULT_USERS;
  }

  // Dashboard: dynamic cards, advanced search, filtering and sorting.
  const studentTable = document.getElementById("student-table");
  const studentSearch = document.getElementById("student-search");
  const studentSearchField = document.getElementById("student-search-field");
  const studentGradeFilter = document.getElementById("student-grade-filter");
  const studentMinScore = document.getElementById("student-min-score");
  const studentSort = document.getElementById("student-sort");
  const studentEmpty = document.getElementById("student-empty");
  const studentCount = document.getElementById("student-count");
  const averageScore = document.getElementById("average-score");
  const topGrade = document.getElementById("top-grade");
  const averageAttendance = document.getElementById("average-attendance");

  function updateDashboardCards(students) {
    if (!studentCount && !averageScore && !topGrade && !averageAttendance) return;

    if (!students.length) {
      if (studentCount) studentCount.textContent = "0";
      if (averageScore) averageScore.textContent = "0%";
      if (topGrade) topGrade.textContent = "—";
      if (averageAttendance) averageAttendance.textContent = "0%";
      return;
    }

    const scoreAverage = students.reduce((sum, student) => sum + Number(student.overall || 0), 0) / students.length;
    const attendanceAverageValue = students.reduce((sum, student) => sum + Number(student.attendance || 0), 0) / students.length;
    const gradeOrder = ["A+", "A", "B+", "B", "C+", "C", "D", "F"];
    const bestGrade = gradeOrder.find((grade) => students.some((student) => student.grade === grade)) || "—";

    if (studentCount) studentCount.textContent = String(students.length);
    if (averageScore) averageScore.textContent = `${scoreAverage.toFixed(1)}%`;
    if (topGrade) topGrade.textContent = bestGrade;
    if (averageAttendance) averageAttendance.textContent = `${attendanceAverageValue.toFixed(1)}%`;
  }

  function renderStudentTable(students) {
    if (!studentTable || !studentTable.tBodies.length) return;
    const tbody = studentTable.tBodies[0];
    const fragment = document.createDocumentFragment();

    students.forEach((student) => {
      const row = document.createElement("tr");
      row.dataset.grade = student.grade;

      const values = [student.id, student.name, `${student.attendance}%`, `${student.overall}%`];
      values.forEach((value) => {
        const cell = document.createElement("td");
        cell.textContent = value;
        row.appendChild(cell);
      });

      const gradeCell = document.createElement("td");
      const badge = document.createElement("span");
      badge.className = `grade ${gradeClass(student.grade)}`;
      badge.textContent = student.grade;
      gradeCell.appendChild(badge);
      row.appendChild(gradeCell);

      const actionCell = document.createElement("td");
      const link = document.createElement("a");
      link.className = "table-link";
      link.href = `profile.html?id=${encodeURIComponent(student.id)}`;
      link.textContent = "View Profile";
      actionCell.appendChild(link);
      row.appendChild(actionCell);
      fragment.appendChild(row);
    });

    tbody.replaceChildren(fragment);

    if (studentEmpty) studentEmpty.hidden = students.length !== 0;
  }

  function filterAndSortStudents() {
    let students = [...getStudents()];
    const query = studentSearch ? studentSearch.value.trim().toLowerCase() : "";
    const field = studentSearchField ? studentSearchField.value : "all";
    const grade = studentGradeFilter ? studentGradeFilter.value : "all";
    const minScoreValue = studentMinScore ? studentMinScore.value.trim() : "";
    const minScore = minScoreValue === "" ? null : Number(minScoreValue);

    if (query) {
      students = students.filter((student) => {
        const values = {
          id: String(student.id).toLowerCase(),
          name: String(student.name).toLowerCase(),
          grade: String(student.grade).toLowerCase()
        };
        if (field === "all") return Object.values(values).some((value) => value.includes(query));
        return values[field] ? values[field].includes(query) : false;
      });
    }

    if (grade !== "all") {
      students = students.filter((student) => student.grade === grade);
    }

    if (minScore !== null && Number.isFinite(minScore)) {
      students = students.filter((student) => Number(student.overall) >= minScore);
    }

    const sortValue = studentSort ? studentSort.value : "id-asc";
    const sorters = {
      "id-asc": (a, b) => a.id.localeCompare(b.id),
      "name-asc": (a, b) => a.name.localeCompare(b.name),
      "name-desc": (a, b) => b.name.localeCompare(a.name),
      "score-desc": (a, b) => Number(b.overall) - Number(a.overall),
      "score-asc": (a, b) => Number(a.overall) - Number(b.overall),
      "attendance-desc": (a, b) => Number(b.attendance) - Number(a.attendance)
    };
    students.sort(sorters[sortValue] || sorters["id-asc"]);

    renderStudentTable(students);
  }

  const debouncedStudentFilter = debounce(filterAndSortStudents, 160);
  [studentSearch, studentMinScore].forEach((control) => {
    if (control) control.addEventListener("input", debouncedStudentFilter);
  });
  [studentSearchField, studentGradeFilter, studentSort].forEach((control) => {
    if (control) control.addEventListener("change", filterAndSortStudents);
  });

  if (studentTable) {
    updateDashboardCards(getStudents());
    filterAndSortStudents();
  }

  const studentForm = document.getElementById("student-form");
  const studentMessage = document.getElementById("student-form-message");

  if (studentForm) {
    studentForm.addEventListener("submit", (event) => {
      event.preventDefault();

      const idInput = document.getElementById("student-id");
      const nameInput = document.getElementById("student-name");
      const attendanceInput = document.getElementById("student-attendance");
      const overallInput = document.getElementById("student-overall");
      const gradeInput = document.getElementById("student-grade");

      const id = idInput.value.trim().toUpperCase();
      const name = nameInput.value.trim();
      const attendance = Number(attendanceInput.value);
      const overall = Number(overallInput.value);
      const grade = gradeInput.value;

      if (!/^ST-\d{4}$/.test(id)) {
        setMessage(studentMessage, "Student ID must use the format ST-1007.", "error");
        idInput.focus();
        return;
      }
      if (name.length < 2) {
        setMessage(studentMessage, "Please enter a valid student name.", "error");
        nameInput.focus();
        return;
      }
      if (!Number.isFinite(attendance) || attendance < 0 || attendance > 100) {
        setMessage(studentMessage, "Attendance must be between 0 and 100.", "error");
        attendanceInput.focus();
        return;
      }
      if (!Number.isFinite(overall) || overall < 0 || overall > 100) {
        setMessage(studentMessage, "Overall percentage must be between 0 and 100.", "error");
        overallInput.focus();
        return;
      }
      if (!grade) {
        setMessage(studentMessage, "Please select a grade.", "error");
        gradeInput.focus();
        return;
      }

      const students = getStudents();
      if (students.some((student) => student.id.toLowerCase() === id.toLowerCase())) {
        setMessage(studentMessage, "Student ID already exists.", "error");
        idInput.focus();
        return;
      }

      students.push({
        id,
        name,
        attendance,
        overall,
        grade,
        assignment: overall,
        quiz: overall,
        mid: overall,
        final: overall
      });
      saveStudents(students);

      studentForm.reset();
      setMessage(studentMessage, "Student record added successfully.", "success");
      updateDashboardCards(students);
      filterAndSortStudents();
    });
  }

  // Reports grade filter.
  const gradeFilter = document.getElementById("grade-filter");
  const reportTable = document.getElementById("report-table");
  const reportEmpty = document.getElementById("report-empty");

  if (gradeFilter && reportTable) {
    gradeFilter.addEventListener("change", () => {
      const selected = gradeFilter.value;
      const rows = Array.from(reportTable.tBodies[0].rows);
      let visibleCount = 0;

      rows.forEach((row) => {
        const matches = selected === "all" || row.dataset.grade === selected;
        row.hidden = !matches;
        if (matches) visibleCount += 1;
      });

      if (reportEmpty) reportEmpty.hidden = visibleCount !== 0;
    });
  }

  // Registration with Local Storage simulation.
  const registerForm = document.getElementById("register-form");
  const registerMessage = document.getElementById("register-message");

  if (registerForm) {
    registerForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const nameInput = document.getElementById("register-name");
      const emailInput = document.getElementById("register-email");
      const roleInput = document.getElementById("register-role");
      const passwordInput = document.getElementById("register-password");
      const confirmInput = document.getElementById("register-confirm-password");

      const name = nameInput.value.trim();
      const email = emailInput.value.trim().toLowerCase();
      const role = normalizeRole(roleInput ? roleInput.value : "student");
      const password = passwordInput.value;
      const confirmPassword = confirmInput.value;

      if (name.length < 2) {
        setMessage(registerMessage, "Please enter your full name.", "error");
        nameInput.focus();
        return;
      }
      if (!isValidEmail(email)) {
        setMessage(registerMessage, "Please enter a valid email address.", "error");
        emailInput.focus();
        return;
      }
      if (password.length < 8) {
        setMessage(registerMessage, "Password must contain at least 8 characters.", "error");
        passwordInput.focus();
        return;
      }
      if (password !== confirmPassword) {
        setMessage(registerMessage, "Passwords do not match.", "error");
        confirmInput.focus();
        return;
      }

      const users = getUsers();
      if (users.some((user) => user.email.toLowerCase() === email)) {
        setMessage(registerMessage, "An account with this email already exists.", "error");
        emailInput.focus();
        return;
      }

      users.push({ name, email, password, role });
      if (!writeStorage(STORAGE_KEYS.users, users)) {
        setMessage(registerMessage, "Local Storage is unavailable in this browser.", "error");
        return;
      }

      setMessage(registerMessage, "Registration successful. Opening login...", "success");
      registerForm.reset();
      window.setTimeout(() => {
        window.location.href = "login.html";
      }, 450);
    });
  }

  // Login supports registered Local Storage users and the seeded demo user.
  const loginForm = document.getElementById("login-form");
  const loginMessage = document.getElementById("login-message");

  if (loginForm) {
    loginForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const emailInput = document.getElementById("login-email");
      const passwordInput = document.getElementById("login-password");
      const email = emailInput.value.trim().toLowerCase();
      const password = passwordInput.value;

      if (!isValidEmail(email)) {
        setMessage(loginMessage, "Please enter a valid email address.", "error");
        emailInput.focus();
        return;
      }
      if (password.length < 6) {
        setMessage(loginMessage, "Password must contain at least 6 characters.", "error");
        passwordInput.focus();
        return;
      }

      const user = getUsers().find((item) => item.email.toLowerCase() === email && item.password === password);
      if (!user) {
        setMessage(loginMessage, "Incorrect email or password.", "error");
        return;
      }

      const signedInUser = { name: user.name, email: user.email, role: normalizeRole(user.role) };
      writeStorage(STORAGE_KEYS.currentUser, signedInUser);
      setMessage(loginMessage, `Login successful. Opening ${signedInUser.role} dashboard...`, "success");
      window.setTimeout(() => {
        window.location.href = roleDashboardPath(signedInUser.role);
      }, 350);
    });
  }

  // Forgot password and reset password UI simulation.
  const forgotForm = document.getElementById("forgot-password-form");
  const forgotMessage = document.getElementById("forgot-password-message");

  if (forgotForm) {
    forgotForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const emailInput = document.getElementById("forgot-email");
      const email = emailInput.value.trim().toLowerCase();

      if (!isValidEmail(email)) {
        setMessage(forgotMessage, "Please enter a valid email address.", "error");
        emailInput.focus();
        return;
      }
      if (!getUsers().some((user) => user.email.toLowerCase() === email)) {
        setMessage(forgotMessage, "No simulated account was found for this email.", "error");
        return;
      }

      writeStorage(STORAGE_KEYS.resetEmail, email);
      setMessage(forgotMessage, "Account verified. Opening reset password...", "success");
      window.setTimeout(() => {
        window.location.href = "reset-password.html";
      }, 400);
    });
  }

  const resetForm = document.getElementById("reset-password-form");
  const resetMessage = document.getElementById("reset-password-message");
  const resetAccount = document.getElementById("reset-account");

  if (resetForm) {
    const resetEmail = readStorage(STORAGE_KEYS.resetEmail, "");
    if (resetAccount) {
      resetAccount.textContent = resetEmail || "No account selected";
    }

    resetForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const passwordInput = document.getElementById("reset-password");
      const confirmInput = document.getElementById("reset-confirm-password");
      const password = passwordInput.value;
      const confirmPassword = confirmInput.value;
      const email = readStorage(STORAGE_KEYS.resetEmail, "");

      if (!email) {
        setMessage(resetMessage, "Start from the Forgot Password page first.", "error");
        return;
      }
      if (password.length < 8) {
        setMessage(resetMessage, "Password must contain at least 8 characters.", "error");
        passwordInput.focus();
        return;
      }
      if (password !== confirmPassword) {
        setMessage(resetMessage, "Passwords do not match.", "error");
        confirmInput.focus();
        return;
      }

      const users = getUsers();
      const user = users.find((item) => item.email.toLowerCase() === email.toLowerCase());
      if (!user) {
        setMessage(resetMessage, "The selected account no longer exists.", "error");
        return;
      }

      user.password = password;
      writeStorage(STORAGE_KEYS.users, users);
      removeStorage(STORAGE_KEYS.resetEmail);
      setMessage(resetMessage, "Password reset successful. Opening login...", "success");
      resetForm.reset();
      window.setTimeout(() => {
        window.location.href = "login.html";
      }, 450);
    });
  }

  // Dynamic student profile page and JavaScript performance cards.
  const profileRoot = document.getElementById("student-profile-root");
  if (profileRoot) {
    const params = new URLSearchParams(window.location.search);
    const requestedId = params.get("id");
    const student = getStudents().find((item) => item.id === requestedId);
    const profileName = document.getElementById("profile-name");
    const profileId = document.getElementById("profile-id");
    const profileGrade = document.getElementById("profile-grade");
    const performanceCards = document.getElementById("performance-cards");
    const profileDetails = document.getElementById("profile-details");
    const profileMissing = document.getElementById("profile-missing");

    if (!student) {
      profileRoot.hidden = true;
      if (profileMissing) profileMissing.hidden = false;
    } else {
      if (profileName) profileName.textContent = student.name;
      if (profileId) profileId.textContent = student.id;
      if (profileGrade) {
        profileGrade.textContent = student.grade;
        profileGrade.className = `grade ${gradeClass(student.grade)}`;
      }

      const cards = [
        ["Overall Score", `${student.overall}%`, "Current performance"],
        ["Attendance", `${student.attendance}%`, "Attendance rate"],
        ["Final Exam", `${student.final}%`, "Final assessment"],
        ["Grade", student.grade, "Current grade"]
      ];

      if (performanceCards) {
        performanceCards.textContent = "";
        cards.forEach(([label, value, note]) => {
          const card = document.createElement("article");
          card.className = "stat-card performance-card reveal";
          const labelElement = document.createElement("span");
          labelElement.className = "stat-label";
          labelElement.textContent = label;
          const valueElement = document.createElement("strong");
          valueElement.textContent = value;
          const noteElement = document.createElement("small");
          noteElement.textContent = note;
          card.append(labelElement, valueElement, noteElement);
          performanceCards.appendChild(card);
        });
      }

      if (profileDetails) {
        const detailItems = [
          ["Assignment Score", student.assignment],
          ["Quiz Score", student.quiz],
          ["Mid Exam Score", student.mid],
          ["Final Exam Score", student.final]
        ];
        profileDetails.textContent = "";
        detailItems.forEach(([label, value]) => {
          const item = document.createElement("div");
          item.className = "profile-detail";
          const labelElement = document.createElement("span");
          labelElement.textContent = label;
          const valueElement = document.createElement("strong");
          valueElement.textContent = `${value}%`;
          item.append(labelElement, valueElement);
          profileDetails.appendChild(item);
        });
      }
    }
  }

  // Contact form validation.
  const contactForm = document.getElementById("contact-form");
  const contactMessage = document.getElementById("contact-form-message");

  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const name = document.getElementById("contact-name").value.trim();
      const email = document.getElementById("contact-email").value.trim();
      const subject = document.getElementById("contact-subject").value.trim();
      const message = document.getElementById("contact-message").value.trim();

      if (name.length < 2 || !isValidEmail(email) || subject.length < 3 || message.length < 10) {
        setMessage(contactMessage, "Please complete the form with valid information.", "error");
        return;
      }

      setMessage(contactMessage, "Message submitted successfully.", "success");
      contactForm.reset();
    });
  }

  // Week 4: role dashboards, notifications, profile management and accessibility controls.
  const notificationToggle = document.getElementById("notification-toggle");
  const notificationPanel = document.getElementById("notification-panel");
  const notificationClose = document.getElementById("notification-close");
  const notificationList = document.getElementById("notification-list");
  const notificationBadge = document.getElementById("notification-badge");
  const markNotificationsRead = document.getElementById("mark-notifications-read");

  function getNotifications() {
    const notifications = readStorage(STORAGE_KEYS.notifications, []);
    return Array.isArray(notifications) ? notifications : [];
  }

  function renderNotifications() {
    const notifications = getNotifications();
    const unreadCount = notifications.filter((item) => !item.read).length;
    if (notificationBadge) {
      notificationBadge.textContent = String(unreadCount);
      notificationBadge.hidden = unreadCount === 0;
    }
    if (!notificationList) return;

    const fragment = document.createDocumentFragment();
    notifications.forEach((notification) => {
      const item = document.createElement("li");
      item.className = `notification-item${notification.read ? "" : " unread"}`;
      const title = document.createElement("strong");
      title.textContent = notification.title;
      const message = document.createElement("span");
      message.textContent = notification.message;
      item.append(title, message);
      fragment.appendChild(item);
    });
    notificationList.replaceChildren(fragment);
  }

  function setNotificationPanel(open) {
    if (!notificationPanel || !notificationToggle) return;
    notificationPanel.hidden = !open;
    notificationToggle.setAttribute("aria-expanded", String(open));
    if (open && notificationClose) notificationClose.focus();
  }

  if (notificationToggle && notificationPanel) {
    renderNotifications();
    notificationToggle.addEventListener("click", () => {
      setNotificationPanel(notificationPanel.hidden);
    });
    if (notificationClose) notificationClose.addEventListener("click", () => setNotificationPanel(false));
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !notificationPanel.hidden) {
        setNotificationPanel(false);
        notificationToggle.focus();
      }
    });
  }

  if (markNotificationsRead) {
    markNotificationsRead.addEventListener("click", () => {
      const notifications = getNotifications().map((item) => ({ ...item, read: true }));
      writeStorage(STORAGE_KEYS.notifications, notifications);
      renderNotifications();
    });
  }

  const logoutButtons = document.querySelectorAll("[data-logout]");
  logoutButtons.forEach((button) => {
    button.addEventListener("click", () => {
      removeStorage(STORAGE_KEYS.currentUser);
      window.location.href = "login.html";
    });
  });

  const accountProfileForm = document.getElementById("account-profile-form");
  const accountProfileMessage = document.getElementById("account-profile-message");
  if (accountProfileForm) {
    const nameInput = document.getElementById("account-name");
    const emailInput = document.getElementById("account-email");
    const roleInput = document.getElementById("account-role");

    if (!currentUser) {
      setMessage(accountProfileMessage, "Please log in to manage your profile.", "error");
      Array.from(accountProfileForm.elements).forEach((element) => { element.disabled = true; });
    } else {
      nameInput.value = currentUser.name || "";
      emailInput.value = currentUser.email || "";
      roleInput.value = normalizeRole(currentUser.role);

      accountProfileForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const name = nameInput.value.trim();
        const email = emailInput.value.trim().toLowerCase();
        if (name.length < 2) {
          setMessage(accountProfileMessage, "Please enter a valid full name.", "error");
          nameInput.focus();
          return;
        }
        if (!isValidEmail(email)) {
          setMessage(accountProfileMessage, "Please enter a valid email address.", "error");
          emailInput.focus();
          return;
        }

        const users = getUsers();
        const duplicate = users.some((user) => user.email.toLowerCase() === email && user.email.toLowerCase() !== currentUser.email.toLowerCase());
        if (duplicate) {
          setMessage(accountProfileMessage, "Another account already uses this email.", "error");
          return;
        }

        const user = users.find((item) => item.email.toLowerCase() === currentUser.email.toLowerCase());
        if (user) {
          user.name = name;
          user.email = email;
          user.role = normalizeRole(user.role);
          writeStorage(STORAGE_KEYS.users, users);
        }
        writeStorage(STORAGE_KEYS.currentUser, { name, email, role: normalizeRole(currentUser.role) });
        setMessage(accountProfileMessage, "Profile updated successfully.", "success");
      });
    }
  }

  const studentRoleCards = document.getElementById("student-role-cards");
  if (studentRoleCards) {
    const students = getStudents();
    const matchedStudent = currentUser
      ? students.find((student) => student.name.toLowerCase() === String(currentUser.name).toLowerCase())
      : null;
    const student = matchedStudent || students[0];

    if (student) {
      const nameElement = document.getElementById("student-role-name");
      const idElement = document.getElementById("student-role-id");
      const gradeElement = document.getElementById("student-role-grade");
      const detailsElement = document.getElementById("student-role-details");
      if (nameElement) nameElement.textContent = student.name;
      if (idElement) idElement.textContent = student.id;
      if (gradeElement) {
        gradeElement.textContent = student.grade;
        gradeElement.className = `grade ${gradeClass(student.grade)}`;
      }

      const metrics = [
        ["Overall Score", `${student.overall}%`, "Current performance"],
        ["Attendance", `${student.attendance}%`, "Attendance rate"],
        ["Assignment", `${student.assignment}%`, "Assignment score"],
        ["Final Exam", `${student.final}%`, "Final assessment"]
      ];
      const fragment = document.createDocumentFragment();
      metrics.forEach(([label, value, note]) => {
        const card = document.createElement("article");
        card.className = "stat-card";
        const labelElement = document.createElement("span");
        labelElement.className = "stat-label";
        labelElement.textContent = label;
        const valueElement = document.createElement("strong");
        valueElement.textContent = value;
        const noteElement = document.createElement("small");
        noteElement.textContent = note;
        card.append(labelElement, valueElement, noteElement);
        fragment.appendChild(card);
      });
      studentRoleCards.replaceChildren(fragment);

      if (detailsElement) {
        const detailFragment = document.createDocumentFragment();
        [["Quiz", student.quiz], ["Mid Exam", student.mid], ["Final Exam", student.final], ["Grade", student.grade]].forEach(([label, value]) => {
          const item = document.createElement("div");
          item.className = "profile-detail";
          const labelElement = document.createElement("span");
          labelElement.textContent = label;
          const valueElement = document.createElement("strong");
          valueElement.textContent = typeof value === "number" ? `${value}%` : value;
          item.append(labelElement, valueElement);
          detailFragment.appendChild(item);
        });
        detailsElement.replaceChildren(detailFragment);
      }
    }
  }

  // Lightweight reveal animations for improved user experience.
  const revealItems = document.querySelectorAll(".stat-card, .feature-card, .panel, .info-panel, .login-card");
  revealItems.forEach((item, index) => {
    item.classList.add("reveal");
    item.style.setProperty("--reveal-delay", `${Math.min(index * 45, 270)}ms`);
  });
})();
